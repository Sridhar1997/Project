import React from 'react';

const RevDataFormComponent = ({ state, setState }) => <>
  <div className="rev-data-form">
    <div className="form-title">
      <p><b>Find out how fast your business will grow.</b></p>
    </div>
    <div className="form-inputs">
      <div className="form-input">
        <label htmlFor="currentMRR">Current MRR</label>
        <input type="number" id="currentMRR" name="currentMRR" value={state.currentMRR} onChange={(e) => { setState('currentMRR', e.currentTarget.value) }} />
      </div>
      <div className="form-input">
        <label htmlFor="revenueGrowth">REVENUE GROWTH</label>
        <input type="number" id="revenueGrowth" name="revenueGrowth" value={state.revenueGrowth} onChange={(e) => { setState('revenueGrowth', e.currentTarget.value) }} />
      </div>
      <div className="form-input">
        <label htmlFor="revenueChurn">REVENUE CHURN</label>
        <input type="number" id="revenueChurn" name="revenueChurn" value={state.revenueChurn} onChange={(e) => { setState('revenueChurn', e.currentTarget.value) }} />
      </div>
      <div className="form-input">
        <label htmlFor="projectionTime">PROJECTION TIME (MONTHS)</label>
        <input type="number" id="projectionTime" name="projectionTime" value={state.projectionTime} onChange={(e) => { setState('projectionTime', e.currentTarget.value) }} />
      </div>
    </div>
  </div>
</>;

const RevTable = () => <>
  <div className="rev-table">
      Table Container
  </div>
</>;

const RevChart = () => <>
  <div className="rev-chart">
    Chart Container
  </div>
</>

const RevDataContainer = ({ state }) => <>
  <div className="rev-data-view-container">
    {
      state.dataView === 'chart'
      && <RevChart />
    }
    {
      state.dataView === 'table'
      && <RevTable />
    }
  </div>
</>;

// const heading={
//   fontsize:'12px',
// }

const RevCard = () => <>
  <div className="rev-card">
    <div className="card-title">
      <h3>Card layout</h3>
    {/* <ul style={heading}> */} <ul>
  How to use the tool?
It is a simple four step process:
    <li>✓ Enter your recurring revenue for the month (MRR)</li>
    <li>✓ Add your revenue growth</li>
    <li>✓ Enter the revenue churned out (you can also add multiple ones and compare)</li>
    <li>✓ And how far into the future you wish to see</li>
  </ul></div>
    </div>
</>;

const RevDataComponent = () => {
  const [revData, setRevData] = React.useState({
    dataView: 'chart',
    currentMRR: 0,
    revenueGrowth: 0,
    revenueChurn: 0,
    projectionTime: 0,
  });

  const handleValueChange = (key, value) => setRevData((prevState) => ({
    ...prevState,
    [key]: value,
  }));

  return <>
    <div className="rev-parent">
      <div className="rev-forecast-container">
        <div className="rev-container">
          <div className="rev-radio-container">
            <input type="radio" name="dataView" id="chart" value='chart' onChange={() => { handleValueChange('dataView', 'chart') }} checked={ revData.dataView === 'chart' } />
            <label htmlFor="chart">Data</label>
            <input type="radio" name="dataView" id="table" value='table' onChange={() => { handleValueChange('dataView', 'table') }} checked={ revData.dataView === 'table' } />
            <label htmlFor="table">Table</label>
          </div>
          <div className="rev-data-container">
            <RevDataFormComponent state={revData} setState={handleValueChange} />
            <RevDataContainer state={revData} />
          </div>
        </div>
        <div className="rev-meta">
          <RevCard />
        </div>
      </div>
    </div>
  </>
};

export default RevDataComponent;