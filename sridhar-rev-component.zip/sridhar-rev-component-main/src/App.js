import './App.css';
import { List } from './Components/ArrayState';
import UserGreeting from './Components/ConditionalRendering';
import Counter from './Components/Counter';
import EventBind from './Components/EventBind';
import FuctionClick from './Components/EventHandling';
import ManyClass from './Components/ManyClass';
import { ObjectExample } from './Components/ObjectState';
import Message2 from './Components/setStateExample';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Pages/Layout";
import Home from "./Pages/Home";
import Blogs from "./Pages/Blogs";
import Contact from "./Pages/Contact";
import Message1 from './Components/StateExample';
import StyleApp from './Components/StyleApp';
import Example1 from './Components/useEffect';

import Example from './Components/useState';
import PageTitleComponent from './Components/PageTitleComponent';
import RevDataComponent from './Components/RevDataComponent';


function App() {
  return (
    <div className="App">
      {/* <h1>Welcome to React Class</h1>
      <p>{12+12}</p> */}
      {/* <Counter/> */}
      {/* <FuctionClick/> */}
      {/* <EventBind/> */}
      {/* <UserGreeting/> */}
      {/* <Example/> */}
      {/* <Example1/> */}
      {/* <StyleApp/> */}
      {/* <ManyClass/> */}
    {/* <List/> */}
    {/* <ObjectExample/> */}
    {/* <Message1/> */}
    {/* <Message2/> */}

    {/* <BrowserRouter>
     
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="contact" element={<Contact />} />
        </Route>
      </Routes>
    </BrowserRouter> */}
    {/* <p><b>Revenue Forecaster</b></p>
    <h1 className='C1'>Revenue forecaster: Predict your business' future revenue</h1>
    <p className='C1'>Plug in your current metrics and calculate future MRR of your subscription business.</p>
    <div class="grid-container">
  <div class="grid-item grid">
    <button>Chart</button><button>Table</button>
    <p>Find out how fast your business will grow.</p>
  </div>
  <div class="grid-item">2</div>
  <div class="grid-item"><ul>
  How to use the tool?
It is a simple four step process:
    <li>✓ Enter your recurring revenue for the month (MRR)</li>
    <li>✓ Add your revenue growth</li>
    <li>✓ Enter the revenue churned out (you can also add multiple ones and compare)</li>
    <li>✓ And how far into the future you wish to see</li>
  </ul></div>  
  </div>
<button className='C2'>Share the Revenue Forecaster</button> */}
<p><b>Revenue Forecaster</b></p>
<h1 className='C1'>Revenue forecaster: Predict your business' future revenue</h1>
<p className='C1'>Plug in your current metrics and calculate future MRR of your subscription business.</p>
<hr></hr>
{/* <PageTitleComponent/> */}
<RevDataComponent/>
    </div>
  );
}

export default App;
